﻿namespace CapaVista
{
    partial class frmUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUsuario));
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            lblBienvenido = new Label();
            btnCatalogoStock = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.ImageLocation = "";
            pictureBox2.Location = new Point(765, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(23, 23);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 82;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.ImageLocation = "";
            pictureBox1.Location = new Point(724, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(23, 23);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 83;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // lblBienvenido
            // 
            lblBienvenido.AutoSize = true;
            lblBienvenido.Font = new Font("Century Gothic", 30F, FontStyle.Bold);
            lblBienvenido.ForeColor = Color.White;
            lblBienvenido.Location = new Point(33, 12);
            lblBienvenido.Name = "lblBienvenido";
            lblBienvenido.Size = new Size(53, 47);
            lblBienvenido.TabIndex = 84;
            lblBienvenido.Text = "...";
            lblBienvenido.Click += lblBienvenido_Click;
            //
            // btnCatalogoStock
            //
            btnCatalogoStock.BackColor = Color.FromArgb(8, 10, 13);
            btnCatalogoStock.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCatalogoStock.ForeColor = Color.White;
            btnCatalogoStock.Anchor = AnchorStyles.None;
            btnCatalogoStock.Location = new Point(271, 206);
            btnCatalogoStock.Name = "btnCatalogoStock";
            btnCatalogoStock.Size = new Size(258, 37);
            btnCatalogoStock.TabIndex = 85;
            btnCatalogoStock.Text = "Catálogo y Stock";
            btnCatalogoStock.UseVisualStyleBackColor = false;
            btnCatalogoStock.Click += btnCatalogoStock_Click;
            //
            // frmUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(8, 10, 13);
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCatalogoStock);
            Controls.Add(lblBienvenido);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox2);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "frmUsuario";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Usuario";
            Load += frmUsuario_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label lblBienvenido;
        private Button btnCatalogoStock;
    }
}