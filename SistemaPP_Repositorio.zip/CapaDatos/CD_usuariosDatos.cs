﻿using System.Data;
using Entidades;
using Microsoft.Data.SqlClient;
using Utilidades;

namespace CapaDatos
{
    public class CD_usuariosDatos : CD_conexion
    {
        public int RegistrarUsuarioCompleto(
            string nombre,
            string apellido,
            string dni,
            string telefono,
            DateTime fechaNacimiento,

            string calle,
            string numero,
            string codigoPostal,
            string depto,
            string piso,
            string provincia,
            string partido,
            string localidad,
            decimal? latitud,
            decimal? longitud,
            string direccionOriginal,
            string direccionNormalizada,

            string usuario,
            string correo,
            string passwordHash,
            int idRol,
            bool usa2FA)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_RegistrarUsuarioCompleto", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Apellido", apellido);
                    cmd.Parameters.AddWithValue("@DNI", dni);
                    cmd.Parameters.AddWithValue("@Telefono", string.IsNullOrWhiteSpace(telefono) ? DBNull.Value : telefono);
                    cmd.Parameters.AddWithValue("@FechaNacimiento", fechaNacimiento);

                    cmd.Parameters.AddWithValue("@Calle", calle);
                    cmd.Parameters.AddWithValue("@Numero", string.IsNullOrWhiteSpace(numero) ? DBNull.Value : numero);
                    cmd.Parameters.AddWithValue("@CodigoPostal", string.IsNullOrWhiteSpace(codigoPostal) ? DBNull.Value : codigoPostal);
                    cmd.Parameters.AddWithValue("@Depto", string.IsNullOrWhiteSpace(depto) ? DBNull.Value : depto);
                    cmd.Parameters.AddWithValue("@Piso", string.IsNullOrWhiteSpace(piso) ? DBNull.Value : piso);
                    cmd.Parameters.AddWithValue("@Provincia", provincia);
                    cmd.Parameters.AddWithValue("@Partido", string.IsNullOrWhiteSpace(partido) ? DBNull.Value : partido);
                    cmd.Parameters.AddWithValue("@Localidad", string.IsNullOrWhiteSpace(localidad) ? DBNull.Value : localidad);
                    cmd.Parameters.AddWithValue("@Latitud", latitud.HasValue ? latitud.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@Longitud", longitud.HasValue ? longitud.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@DireccionOriginal", string.IsNullOrWhiteSpace(direccionOriginal) ? DBNull.Value : direccionOriginal);
                    cmd.Parameters.AddWithValue("@DireccionNormalizada", string.IsNullOrWhiteSpace(direccionNormalizada) ? DBNull.Value : direccionNormalizada);

                    cmd.Parameters.AddWithValue("@Usuario", usuario);
                    cmd.Parameters.AddWithValue("@Correo", correo);
                    cmd.Parameters.AddWithValue("@PasswordHash", passwordHash);
                    cmd.Parameters.AddWithValue("@IdRol", idRol);
                    cmd.Parameters.AddWithValue("@Usa2FA", usa2FA);

                    object resultado = cmd.ExecuteScalar();

                    return resultado != null ? Convert.ToInt32(resultado) : -1;
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.RegistrarUsuarioCompleto", ex);
                throw new Exception("Error SQL al registrar usuario: " + ex.Message, ex);
            }
        }

        public bool AsignarRolUsuario(int idUsuario, int idRol)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_AsignarRolUsuario", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@IdUsuario", idUsuario);
                    cmd.Parameters.AddWithValue("@IdRol", idRol);

                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.AsignarRolUsuario", ex);
                return false;
            }
        }

        public List<rol> ListarRoles()
        {
            List<rol> roles = new List<rol>();

            using (SqlConnection conexion = conectar())
            {
                SqlCommand cmd = new SqlCommand("SP_ListarRoles", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    roles.Add(new rol
                    {
                        IdRol = Convert.ToInt32(reader["IdRol"]),
                        NombreRol = reader["NombreRol"].ToString()
                    });
                }

                reader.Close();
            }

            return roles;
        }

        public int BuscarUsuarioPorNombreUser(string usuario)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_BuscarUsuarioPorNombreUser", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Usuario", usuario);

                    object resultado = cmd.ExecuteScalar();
                    return resultado != null ? Convert.ToInt32(resultado) : 0;
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.BuscarUsuarioPorNombreUser", ex);
                return 0;
            }
        }

        public DataTable BuscarUsuarioPorCorreo(string correo)
        {
            DataTable tabla = new DataTable();

            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_BuscarUsuarioPorCorreo", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Correo", correo);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(tabla);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.BuscarUsuarioPorCorreo", ex);
                tabla = new DataTable();
            }

            return tabla;
        }

        public string BuscarUsuarioPorId(int idUsuario)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_BuscarUsuarioPorId", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@IdUsuario", idUsuario);

                    object resultado = cmd.ExecuteScalar();
                    return resultado != null ? resultado.ToString() : string.Empty;
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.BuscarUsuarioPorId", ex);
                return string.Empty;
            }
        }

        public DataTable BuscarPersonaPorPartido(string partido)
        {
            DataTable tabla = new DataTable();

            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_BuscarPersonaPorPartido", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Partido", partido);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(tabla);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.BuscarPersonaPorPartido", ex);
            }

            return tabla;
        }

        public DataTable BuscarPersonaPorLocalidad(string localidad)
        {
            DataTable tabla = new DataTable();

            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_BuscarPersonaPorLocalidad", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Localidad", localidad);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(tabla);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.BuscarPersonaPorLocalidad", ex);
            }

            return tabla;
        }

        public DataTable BuscarPersonaPorCP(string codigoPostal)
        {
            DataTable tabla = new DataTable();

            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_BuscarPersonaPorCP", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CodigoPostal", codigoPostal);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(tabla);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.BuscarPersonaPorCP", ex);
            }

            return tabla;
        }

        public bool ExisteUsuario(string usuario)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand(
                        "SP_ExisteUsuario",
                        conexion);

                    cmd.CommandType =
                        CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue(
                        "@Usuario",
                        usuario);

                    object resultado =
                        cmd.ExecuteScalar();

                    return Convert.ToBoolean(resultado);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.ExisteUsuario", ex);
                return false;
            }
        }

        public bool ExisteCorreo(string correo)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_ExisteCorreo", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Correo", correo);

                    object resultado = cmd.ExecuteScalar();
                    return Convert.ToBoolean(resultado);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.ExisteCorreo", ex);
                return false;
            }
        }

        public bool ExisteDNI(string dni)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_ExisteDNI", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DNI", dni);

                    object resultado = cmd.ExecuteScalar();
                    return Convert.ToBoolean(resultado);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.ExisteDNI", ex);
                return false;
            }
        }

        public bool UsuarioActivo(string usuario)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("dbo.SP_UsuarioActivo", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Usuario", usuario);

                    object result = cmd.ExecuteScalar();

                    return result != null && Convert.ToBoolean(result);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.UsuarioActivo", ex);
                return false;
            }
        }

        // Nombre, apellido, DNI y fecha de nacimiento reales del usuario, usados
        // en CL_servicioContras para validar que la contraseña no los contenga.
        public (string nombre, string apellido, string dni, DateTime? fechaNacimiento) ObtenerDatosPersonalesPorUsuario(string usuario)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("dbo.SP_ObtenerDatosPersonalesPorUsuario", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Usuario", usuario);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        string nombre = reader["Nombre"].ToString();
                        string apellido = reader["Apellido"].ToString();
                        string dni = reader["DNI"].ToString();
                        DateTime? fechaNacimiento = reader["FechaNacimiento"] == DBNull.Value
                            ? (DateTime?)null
                            : Convert.ToDateTime(reader["FechaNacimiento"]);

                        reader.Close();
                        return (nombre, apellido, dni, fechaNacimiento);
                    }

                    reader.Close();
                    return (string.Empty, string.Empty, string.Empty, null);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.ObtenerDatosPersonalesPorUsuario", ex);
                return (string.Empty, string.Empty, string.Empty, null);
            }
        }

        public bool EsPrimerLogin(string usuario)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_EsPrimerLogin", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Usuario", usuario);

                    object resultado = cmd.ExecuteScalar();
                    return Convert.ToBoolean(resultado);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.EsPrimerLogin", ex);
                return false;
            }
        }

        // Rol de un usuario activo a partir de su ID (0 si no existe o está inactivo).
        public int ObtenerRolPorId(int idUsuario)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SELECT IdRol FROM dbo.Usuarios WHERE IdUsuario = @IdUsuario AND Activo = 1", conexion);
                    cmd.Parameters.AddWithValue("@IdUsuario", idUsuario);

                    object resultado = cmd.ExecuteScalar();

                    return resultado == null || resultado == DBNull.Value ? 0 : Convert.ToInt32(resultado);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.ObtenerRolPorId", ex);
                return 0;
            }
        }

        public int ObtenerRolUsuario(string usuario)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("dbo.SP_ObtenerRolUsuario", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Usuario", usuario);

                    object resultado = cmd.ExecuteScalar();

                    if (resultado == null || resultado == DBNull.Value)
                        return 0;

                    return Convert.ToInt32(resultado);
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.ObtenerRolUsuario", ex);
                throw new Exception("Error SQL al obtener el rol del usuario: " + ex.Message, ex);
            }
        }

        public int RegistrarPersonaUsuarioConDireccion(
            string nombre,
            string apellido,
            string dni,
            string telefono,
            string calle,
            string numero,
            string codigoPostal,
            string depto,
            string piso,
            string provincia,
            string partido,
            string localidad,
            string direccionOriginal,
            string direccionNormalizada,
            DateTime fechaNacimiento,
            string usuario,
            string correo,
            string passwordHash,
            int idRol)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("SP_RegistrarUsuarioCompleto", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Apellido", apellido);
                    cmd.Parameters.AddWithValue("@DNI", dni);
                    cmd.Parameters.AddWithValue("@Telefono", telefono);
                    cmd.Parameters.AddWithValue("@FechaNacimiento", fechaNacimiento);

                    cmd.Parameters.AddWithValue("@Calle", calle);
                    cmd.Parameters.AddWithValue("@Numero", numero);
                    cmd.Parameters.AddWithValue("@CodigoPostal", codigoPostal);
                    cmd.Parameters.AddWithValue("@Depto", depto);
                    cmd.Parameters.AddWithValue("@Piso", piso);
                    cmd.Parameters.AddWithValue("@Provincia", provincia);
                    cmd.Parameters.AddWithValue("@Partido", partido);
                    cmd.Parameters.AddWithValue("@Localidad", localidad);
                    cmd.Parameters.AddWithValue("@Latitud", DBNull.Value);
                    cmd.Parameters.AddWithValue("@Longitud", DBNull.Value);
                    cmd.Parameters.AddWithValue("@DireccionOriginal", direccionOriginal);
                    cmd.Parameters.AddWithValue("@DireccionNormalizada", direccionNormalizada);

                    cmd.Parameters.AddWithValue("@Usuario", usuario);
                    cmd.Parameters.AddWithValue("@Correo", correo);
                    cmd.Parameters.AddWithValue("@PasswordHash", passwordHash);
                    cmd.Parameters.AddWithValue("@IdRol", idRol);
                    cmd.Parameters.AddWithValue("@Usa2FA", false);

                    object resultado = cmd.ExecuteScalar();

                    return resultado != null ? Convert.ToInt32(resultado) : 0;
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.RegistrarPersonaUsuarioConDireccion", ex);
                return 0;
            }
        }

        public bool CambiarEstadoUsuario(int idUsuario, bool activo)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("dbo.SP_ActualizarEstadoUsuario", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@IdUsuario", idUsuario);
                    cmd.Parameters.AddWithValue("@Activo", activo);

                    object resultado = cmd.ExecuteScalar();

                    return resultado != null &&
                           Convert.ToInt32(resultado) == 1;
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.CambiarEstadoUsuario", ex);
                throw new Exception("Error al cambiar estado del usuario: " + ex.Message);
            }
        }

        public bool ActualizarDatosUsuario(
            int idUsuario,

            string nombre,
            string apellido,
            string dni,
            string telefono,
            DateTime fechaNacimiento,

            string calle,
            string numero,
            string codigoPostal,
            string depto,
            string piso,
            string provincia,
            string partido,
            string localidad,
            decimal? latitud,
            decimal? longitud,
            string direccionOriginal,
            string direccionNormalizada,

            string correo,
            int idRol)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("dbo.SP_ActualizarDatosUsuario", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@IdUsuario", idUsuario);

                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Apellido", apellido);
                    cmd.Parameters.AddWithValue("@DNI", dni);
                    cmd.Parameters.AddWithValue("@Telefono", telefono);
                    cmd.Parameters.AddWithValue("@FechaNacimiento", fechaNacimiento);

                    cmd.Parameters.AddWithValue("@Calle", calle);
                    cmd.Parameters.AddWithValue("@Numero", numero);
                    cmd.Parameters.AddWithValue("@CodigoPostal", codigoPostal);
                    cmd.Parameters.AddWithValue("@Depto", string.IsNullOrWhiteSpace(depto) ? DBNull.Value : depto);
                    cmd.Parameters.AddWithValue("@Piso", string.IsNullOrWhiteSpace(piso) ? DBNull.Value : piso);
                    cmd.Parameters.AddWithValue("@Provincia", provincia);
                    cmd.Parameters.AddWithValue("@Partido", partido);
                    cmd.Parameters.AddWithValue("@Localidad", localidad);
                    cmd.Parameters.AddWithValue("@Latitud", latitud.HasValue ? latitud.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@Longitud", longitud.HasValue ? longitud.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@DireccionOriginal", direccionOriginal);
                    cmd.Parameters.AddWithValue("@DireccionNormalizada", direccionNormalizada);

                    cmd.Parameters.AddWithValue("@Correo", correo);
                    cmd.Parameters.AddWithValue("@IdRol", idRol);

                    object resultado = cmd.ExecuteScalar();

                    return resultado != null && Convert.ToInt32(resultado) == 1;
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.ActualizarDatosUsuario", ex);
                throw new Exception("Error SQL al actualizar usuario: " + ex.Message, ex);
            }
        }

        public string ObtenerCorreoPorUsuario(string usuario)
        {
            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("dbo.SP_ObtenerCorreoPorUsuario", conexion);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Usuario", usuario);

                    object resultado = cmd.ExecuteScalar();

                    return resultado != null ? resultado.ToString() : "";
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.ObtenerCorreoPorUsuario", ex);
                return "";
            }
        }

        public List<UsuarioGrilla> ObtenerUsuariosGrilla()
        {
            List<UsuarioGrilla> lista = new List<UsuarioGrilla>();

            try
            {
                using (SqlConnection conexion = conectar())
                {
                    SqlCommand cmd = new SqlCommand("dbo.SP_ObtenerUsuariosGrilla", conexion);
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        lista.Add(new UsuarioGrilla
                        {
                            IdUsuario = Convert.ToInt32(reader["IdUsuario"]),
                            IdPersona = Convert.ToInt32(reader["IdPersona"]),
                            IdDireccion = reader["IdDireccion"] == DBNull.Value ? 0 : Convert.ToInt32(reader["IdDireccion"]),

                            Nombre = reader["Nombre"].ToString(),
                            Apellido = reader["Apellido"].ToString(),
                            DNI = reader["DNI"].ToString(),
                            Telefono = reader["Telefono"].ToString(),

                            Usuario = reader["Usuario"].ToString(),
                            Correo = reader["Correo"].ToString(),
                            IdRol = Convert.ToInt32(reader["IdRol"]),
                            Rol = reader["Rol"].ToString(),

                            Activo = Convert.ToBoolean(reader["Activo"]),
                            Estado = reader["Estado"].ToString(),

                            Calle = reader["Calle"].ToString(),
                            Numero = reader["Numero"].ToString(),
                            CodigoPostal = reader["CodigoPostal"].ToString(),
                            Depto = reader["Depto"].ToString(),
                            Piso = reader["Piso"].ToString(),
                            Provincia = reader["Provincia"].ToString(),
                            Partido = reader["Partido"].ToString(),
                            Localidad = reader["Localidad"].ToString(),

                            FechaNacimiento = Convert.ToDateTime(reader["FechaNacimiento"])
                        });
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Logger.RegistrarError("CD_usuariosDatos.ObtenerUsuariosGrilla", ex);
                throw new Exception("Error SQL al obtener usuarios para la grilla: " + ex.Message, ex);
            }

            return lista;
        }

        public DataTable BuscarUsuariosParaGrilla(string texto, string filtro)
        {
            DataTable tabla = new DataTable();

            using (SqlConnection conexion = conectar())
            {
                SqlCommand cmd = new SqlCommand("dbo.SP_BuscarUsuariosGrilla", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                bool? activo = null;
                int? idRol = null;

                if (filtro == "Usuarios Activos")
                    activo = true;
                else if (filtro == "Usuarios Inactivos")
                    activo = false;
                else if (filtro == "Rol Usuario")
                    idRol = 1;
                else if (filtro == "Rol Administrador")
                    idRol = 2;

                cmd.Parameters.AddWithValue("@Busqueda", texto);

                if (activo.HasValue)
                    cmd.Parameters.AddWithValue("@Activo", activo.Value);
                else
                    cmd.Parameters.AddWithValue("@Activo", DBNull.Value);

                if (idRol.HasValue)
                    cmd.Parameters.AddWithValue("@IdRol", idRol.Value);
                else
                    cmd.Parameters.AddWithValue("@IdRol", DBNull.Value);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(tabla);
            }

            return tabla;
        }
    }
}
